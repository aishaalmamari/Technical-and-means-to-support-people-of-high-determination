<?php
session_start();
$conn = new mysqli("localhost", "root", "", "project");
$result = $conn->query("SELECT * FROM users WHERE role='user'");
?>
<!DOCTYPE html>
<html>
<head>
  <title>All Users</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h2>Registered Users</h2>
  <table border="1" cellpadding="8" cellspacing="0">
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th><th>Gender</th><th>Disability</th></tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= $row['fullname'] ?></td>
      <td><?= $row['email'] ?></td>
      <td><?= $row['age'] ?></td>
      <td><?= $row['gender'] ?></td>
      <td><?= $row['disability'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>