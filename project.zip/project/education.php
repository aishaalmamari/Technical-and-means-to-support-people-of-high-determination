<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Educational</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="navbar">
    <img src="logo.png" alt="Logo" style="width: 150px; height: auto;">
    <button onclick="location.href='index.html'">Sign Out</button>
    <button onclick="location.href='update_info.html'">Update Info</button>
    <button onclick="location.href='feedback.html'">Parents</button>
    <button onclick="location.href='health.html'">Health Services</button>
    <button onclick="location.href='Educational.html'">Education Services</button>
    <button onclick="location.href='entertainment.html'">Entertainment Services</button>
  </div>
    <!-- English Courses -->
    <section class="course-section">
      <h2>English Courses</h2>
      <div class="course-box">
          <p><a href="https://www.starfall.com/h/abcs/">Learn the Alphabet</a></p>
          <div class="course-info">
              <p>Learn English First Course</p>
              <img src="english1.png" alt="English Course">
          </div>
      </div>
      <div class="course-box">
          <button class="learn-btn">Learn Now</button>
          <div class="course-info">
              <p>Learn English Second Course</p>
              <img src="english2.jpg" alt="English Course">
          </div>
      </div>
  </section>

  <!-- IT Courses -->
  <section class="course-section">
      <h2>Information Technology Courses</h2>
      <div class="course-box">
          <button class="learn-btn">Learn Now</button>
          <div class="course-info">
              <p>Learn Excel Course</p>
              <img src="excel.jpg" alt="Excel Icon">
          </div>
      </div>
      <div class="course-box">
          <button class="learn-btn">Learn Now</button>
          <div class="course-info">
              <p>Learn Word Course</p>
              <img src="word.jpg" alt="Word Icon">
          </div>
      </div>
  </section>

  <section class="course-section">
    <h2>Sign language Courses</h2>
    <div class="course-box">
        <button class="learn-btn">Learn Now</button>
        <div class="course-info">
            <p>Learn Numbers Sign Language Course</p>
            <img src="Sign language1.jpeg" alt="Excel Icon">
        </div>
    </div>
    <div class="course-box">
        <button class="learn-btn">Learn Now</button>
        <div class="course-info">
            <p>Learn Letters Sign Language Course</p>
            <img src="Sign language2.jpeg" alt="Word Icon">
        </div>
    </div>
</section>
</body>
</html>