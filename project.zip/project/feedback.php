<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
  <meta charset="UTF-8">
  <title>Parents Page</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="navbar">
    <img src="logo.png" alt="Logo" style="width: 150px; height: auto;">
    <button onclick="location.href='index.html'">Sign Out</button>
    <button onclick="location.href='update-info.html'">Update Info</button>
    <button onclick="location.href='feedback.html'">Parents</button>
    <button onclick="location.href='health.html'">Health Services</button>
    <button onclick="location.href='Educational.html'">Education Services</button>
    <button onclick="location.href='entertainment.html'">Entertainment Services</button>
    <button onclick="location.href='parents-ar.html'">العربية</button>
  </div>

  <div class="parents-container">
    <h2>Parents Feedback</h2>
    <form class="survey-form" action="submit.php" method="post">
      <p>What is your opinion about this website:</p>
      <label><input type="radio" name="opinion" value="excellent"> Excellent</label><br>
      <label><input type="radio" name="opinion" value="good"> Good</label><br>
      <label><input type="radio" name="opinion" value="bad"> Bad</label><br><br>

      <p>What is your child understanding from educational services:</p>
      <label><input type="radio" name="understanding" value="excellent"> Excellent</label><br>
      <label><input type="radio" name="understanding" value="good"> Good</label><br>
      <label><input type="radio" name="understanding" value="bad"> Bad</label><br><br>

      <p>What is your child benefit from educational services:</p>
      <label><input type="radio" name="benefit" value="excellent"> Excellent</label><br>
      <label><input type="radio" name="benefit" value="good"> Good</label><br>
      <label><input type="radio" name="benefit" value="bad"> Bad</label><br><br>

      <p>Is entertainment services are suitable for your child?</p>
      <label><input type="radio" name="entertainment" value="yes"> Yes</label><br>
      <label><input type="radio" name="entertainment" value="little"> Little</label><br>
      <label><input type="radio" name="entertainment" value="no"> No</label><br><br>

      <p>How satisfied are you with the health services provided?</p>
      <label><input type="radio" name="health" value="Excellent"> Excellent</label><br>
      <label><input type="radio" name="health" value="Good"> Good</label><br>
      <label><input type="radio" name="health" value="Bad"> Bad</label><br><br>

      <p>If you have a comment please mention it:</p>
      <textarea name="comment" placeholder="Write your comment here..."></textarea><br><br>

      <button type="submit">Submit</button>
    </form>
  </div>
</body>
</html>