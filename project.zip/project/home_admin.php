<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
  header("Location: admin_login.html");
  exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h2>Admin Dashboard</h2>
    <ul>
        <li><a href="view_users.php">view users</a></li>
        <li><a href="view_questions.php">view questions</a></li>
        <li><a href="view_feedback.php">view feedback</a></li>
        <li><a href="logout.php">log out</a></li>
    </ul>
</body>
</html>
