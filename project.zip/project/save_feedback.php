<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.html");
  exit();
}

$conn = new mysqli("localhost", "root", "", "project");
$feedback = $_POST['feedback'];
$user_id = $_SESSION['user_id'];

$sql = "INSERT INTO feedback (user_id, feedback_text) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $feedback);
$stmt->execute();

header("Location: user_home.php");
?>