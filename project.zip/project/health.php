<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Preview Health</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="navbar">
    <img src="logo.png" alt="Logo" style="width: 150px; height: auto;">
    <button onclick="location.href='index.html'">Sign Out</button>
    <button onclick="location.href='update_info.html'">Update Info</button>
    <button onclick="location.href='feedback.html'">Parents</button>
    <button onclick="location.href='health.html'">Health Services</button>
    <button onclick="location.href='Educational.html'">Education Services</button>
    <button onclick="location.href='entertainment.html'">Entertainment Services</button>
    <button onclick="location.href='education-ar.html'">العربية</button>
  </div>

  <div class="health-container">

    <div class="box">
      <h2>BMI is:</h2>
      <p>183.88318009735</p>
    </div>

    <div class="box">
      <h2>Based on your BMI</h2>
      <p>you have type 3 obesity, please eat a healthy diet and exercise as much as possible</p>
    </div>

    <div class="box">
      <h2>Ask the nurse</h2>
      <form action="save_question.php" method="post">
              <textarea name="question" placeholder="Write your question here" required></textarea>
      <button type="submit">Send</button>
    </form>
    </div>

    <div class="box">
      <button onclick="window.location.href='show_question.php'">view questions</button>
    </div>
  </div>
</body>
</html>