<?php
session_start();
$conn = new mysqli("localhost", "root", "", "project");

if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        isset($_POST['fullname']) && isset($_POST['email']) && isset($_POST['password']) &&
        isset($_POST['age']) && isset($_POST['weight']) && isset($_POST['height']) &&
        isset($_POST['gender']) && isset($_POST['disability'])
    ) {
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $age = intval($_POST['age']);
        $weight = intval($_POST['weight']);
        $height = intval($_POST['height']);
        $gender = $_POST['gender'];
        $disability = $_POST['disability'];
        $role = 'user';

        $sql = "INSERT INTO users (fullname, email, password, age, weight, height, gender, disability, role)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("فشل في تجهيز الاستعلام: " . $conn->error);
        }

        $stmt->bind_param("sssiiisss", $fullname, $email, $password, $age, $weight, $height, $gender, $disability, $role);

        if ($stmt->execute()) {
            header("Location: login.php");
            exit();
        } else {
            echo "حدث خطأ أثناء التسجيل: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "الرجاء تعبئة جميع الحقول المطلوبة.";
    }
}

$conn->close();
?>