<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
$conn = new mysqli("localhost", "root", "", "project");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = $_POST['email'];
  $password = $_POST['password'];
  $role = $_POST['role']??'';

  if ($role === 'admin') {
    // فقط يسمح لك أنت كـ Admin
    if ($email === 'f202000473@buc.edu.om' && $password === '202000473') {
      $_SESSION['user_id'] = 'admin';
      $_SESSION['role'] = 'admin';
      header("Location: home_admin.php");
      exit();
    } else {
      echo "أنت لست المشرف المصرح له.";
      exit();
    }
  }

  // تحقق من Nurse من قاعدة البيانات
  if ($role === 'nurse') {
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'nurse'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
      if (password_verify($password, $row['password'])) {
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['role'] = 'nurse';
        header("Location: home_nurse.php");
        exit();
      } else {
        echo "كلمة المرور غير صحيحة.";
      }
    } else {
      echo "لا يوجد حساب ممرضة بهذا البريد.";
    }
  }
}
?>