<?php
session_start();
$conn = new mysqli("localhost", "root", "", "project");

$result = $conn->query("SELECT q.*, u.email FROM questions q JOIN users u ON q.user_id = u.id");
?>
<!DOCTYPE html>
<html>
<head>
  <title>All Questions</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h2>User Questions</h2>
  <table border="1" cellpadding="8" cellspacing="0">
    <tr><th>User</th><th>Question</th><th>Answer</th></tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['email'] ?></td>
      <td><?= $row['question_text'] ?></td>
      <td><?= $row['answer'] ?: "No answer yet" ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>