<?php
session_start();
$conn = new mysqli("localhost", "root", "", "project");

$result = $conn->query("SELECT f.*, u.email FROM feedback f JOIN users u ON f.user_id = u.id");
?>
<!DOCTYPE html>
<html>
<head>
  <title>All Feedback</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h2>User Feedback</h2>
  <table border="1" cellpadding="8" cellspacing="0">
    <tr><th>User</th><th>Feedback</th></tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['email'] ?></td>
      <td><?= $row['feedback_text'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>