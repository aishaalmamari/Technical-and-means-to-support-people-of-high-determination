<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Entertainment Services</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="navbar">
        <img src="logo.png" alt="Logo" style="width: 150px; height: auto;">
        <button onclick="location.href='index.html'">Sign Out</button>
        <button onclick="location.href='update-info.html'">Update Info</button>
        <button onclick="location.href='feedback.html'">Parents</button>
        <button onclick="location.href='health.html'">Health Services</button>
        <button onclick="location.href='educational.html'">Education Services</button>
        <button onclick="location.href='entertainment.html'">Entertainment Services</button>
        <button onclick="location.href='entertainment-ar.html'">العربية</button>
      </div>

    <section class="course-section">
        <h2>Exercises</h2>
        <div class="course-box">
            <button class="learn-btn">Learn Now</button>
            <div class="course-info">
                <p>Exercise 1</p>
                <img src="exercise1.jpeg" alt="Exercise Icon">
            </div>
        </div>
        <div class="course-box">
            <button class="learn-btn">Learn Now</button>
            <div class="course-info">
                <p>Exercise 2</p>
                <img src="exercise2.jpeg" alt="Exercise Icon">
            </div>
        </div>
    </section>

    <section class="course-section">
        <h2>Stories</h2>
        <div class="course-box">
            <button class="learn-btn">Learn Now</button>
            <div class="course-info">
                <p>Story 1</p>
                <img src="story1.jpeg" alt="Story Icon">
            </div>
        </div>
        <div class="course-box">
            <button class="learn-btn">Learn Now</button>
            <div class="course-info">
                <p>Story 2</p>
                <img src="story2.jpeg" alt="Story Icon">
            </div>
        </div>
    </section>

</body>
</html>