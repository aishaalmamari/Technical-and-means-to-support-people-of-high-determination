<?php
session_start();
if ($_SESSION['role'] !== 'user') {
  header("Location: login.html");
  exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>User Home</title>
</head>
<body>
  <h2>Welcome to your dashboard</h2>
  <ul>
    <li><a href="ask_question.html">Ask a Question</a></li>
    <li><a href="feedback.html">Send Feedback</a></li>
    <li><a href="update_info.html">Update Info</a></li>
    <li><a href="health.html">Preview Health</a></li>
    <li><a href="entertainment.html">Entertainment</a></li>
    <li><a href="education.html">Educational</a></li>
    <li><a href="logout.php">Sign Out</a></li>
  </ul>
</body>
</html>