<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.html");
  exit();
}

$conn = new mysqli("localhost", "root", "", "project");
$user_id = $_SESSION['user_id'];
$name = $_POST['fullname'];
$age = $_POST['age'];
$weight = $_POST['weight'];
$height = $_POST['height'];

$sql = "UPDATE users SET fullname=?, age=?, weight=?, height=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("siiii", $name, $age, $weight, $height, $user_id);
$stmt->execute();

header("Location: user_home.php");
?>