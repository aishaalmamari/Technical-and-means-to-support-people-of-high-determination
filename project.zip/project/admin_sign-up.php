<?php
$conn = new mysqli("localhost", "root", "", "project");

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password'];
$category = $_POST['category'];
$role = 'admin';

$sql = "INSERT INTO users (fullname, email, password, category, role)
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssiiisss", $fullname, $email, $password,  $category,  $role);
$stmt->execute();

header("Location: admin_login.html");

?>
