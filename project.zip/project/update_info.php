<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Information</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="navbar">
        <img src="logo.png" alt="Logo" style="width: 150px;height: auto;">
        <button onclick="location.href='index.html'">Sign Out</button>
        <button class="active" onclick="location.href='update-info.html'">Update Info</button>
        <button onclick="location.href='feedback.html'">Parents</button>
        <button onclick="location.href='health.html'">Health Services</button>
        <button onclick="location.href='educational.html'">Education Services</button>
        <button onclick="location.href='entertainment.html'">Entertainment Services</button>
        <button onclick="location.href='about.html'">About Us</button>
        <button onclick="location.href='update-info-ar.html'">العربية</button>
    </div>

    <div class="form-container">
        <h2>Update Information</h2>
        <form action="save_update_info.php"method="post">
            <label>Full Name</label>
            <input type="text" name="fullname" value="">

            <label>Email</label>
            <input type="email" name="email" value="">

            <label>Password</label>
            <input type="password" name="password" value="">

            <label>Confirm Password</label>
            <input type="password" name="confirm-password" value="">

            <label>Age</label>
            <input type="number" name="age" value="">

            <label>Weight</label>
            <input type="number" name="weight" value="">

            <label>Height</label>
            <input type="number" name="height" value="">

            <label>Gender</label>
            <select name="gender">
                <option value="female">Female</option>
                <option value="male">Male</option>
            </select>

            <label>Disability</label>
            <input type="text" name="disability" value="">

            <button type="submit" class="submit-btn">Update</button>
        </form>
    </div>
</body>
</html>