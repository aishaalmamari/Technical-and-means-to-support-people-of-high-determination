<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.html");
  exit();
}

$conn = new mysqli("localhost", "root", "", "project");
$question = $_POST['question'];
$user_id = $_SESSION['user_id'];

$sql = "INSERT INTO questions (user_id, question_text) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_id, $question);
$stmt->execute();

header("Location: user_home.php");
?>